using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OrderProcessingApi.Models;
using OrderProcessingApi.Services;

public class OrdersModel : PageModel
{
    private readonly IOrderService _orderService;

    [BindProperty]

 
    public OrderItem OrderItem { get; set; } = new();

    [BindProperty]
    public string OrderIdToCancel { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public string OrderIdToCheck { get; set; } = string.Empty;
    public Guid OrderId { get; private set; }
    public string OrderStatus { get; set; } = string.Empty;

    public OrdersModel(IOrderService orderService)
    {
        _orderService = orderService;
    }

    public void OnGet()
    {
    }

    public async Task<IActionResult> OnPostPlaceOrderAsync()
    {
       

        var order = await _orderService.PlaceOrderAsync(new List<OrderItem> { OrderItem });
        OrderId = order.Id;
        OrderStatus = order.Status.ToString();
        // Redirect so the URL can include the new OrderId (optional)
        //return RedirectToPage(new { OrderIdToCheck = order.Id });
        return Page();
    }

    public async Task<IActionResult> OnPostCancelOrderAsync()
    {
        if (!string.IsNullOrEmpty(OrderIdToCancel))
        {
            await _orderService.CancelOrderAsync(Guid.Parse(OrderIdToCancel));
            OrderStatus = "Canceled";
        }
        return RedirectToPage();
    }

    /*public async Task<IActionResult> OnGetCheckStatusAsync(string OrderIdToCheck)
    {
        if (!string.IsNullOrWhiteSpace(OrderIdToCheck))
        {
            try
            {
                var order = await _orderService.GetOrderAsync(Guid.Parse(OrderIdToCheck));
                OrderStatus = order.Status.ToString();
            }
            catch (Exception ex)
            {
                OrderStatus = "Error: " + ex.Message;
            }
        }
        return Page();
    }*/
    public async Task<IActionResult> OnGetCheckStatusAsync()
    {
        if (!string.IsNullOrWhiteSpace(OrderIdToCheck))
        {
            try
            {
                var order = await _orderService.GetOrderAsync(Guid.Parse(OrderIdToCheck));
                OrderStatus = order.Status.ToString();
            }
            catch (Exception ex)
            {
                OrderStatus = "Error: " + ex.Message;
            }
        }
        return Page();
    }
}
